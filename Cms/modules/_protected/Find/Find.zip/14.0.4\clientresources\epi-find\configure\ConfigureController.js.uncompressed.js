﻿define("epi-find/configure/ConfigureController", [
    "dojo/_base/declare",

    "../_ControllerBase",
    "./ConfigureModel",
    "../widget/Configure",
    "../widget/_ActionableMixin"


],
function(declare,
    _ControllerBase,
    ConfigureModel, Configure, _ActionableMixin
) {
    return declare([_ControllerBase, _ActionableMixin], {
        // summary: 
        //      Controller for Manage views.

        model: null,

        widget: null,

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this.inherited(arguments);
            this.model = new ConfigureModel();
            this.model.init();

            this.widget = new Configure({
                model: this.model
            });

            this.own(this.widget);
        },

        show: function() {
            this._setupView([this.widget]);
        },

        takeAction: function(actions, params) {
            this.widget.takeAction(actions, params);
            this.currentAction = this.widget.currentAction;
            return this.widget;
        }
    });
});