//>>built
define("epi-find/nls/ja/ConfigModel",{"configErrorMessage":"エラー読み取り構成。"});