﻿define("epi-find/store/Optimization", [
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/Deferred",
        "dojo/Evented",
        "./ResourceStore"
],
function (declare,
          lang,
          Deferred,
          Evented,
          ResourceStore) {

    return declare([ResourceStore, Evented], {
        // summary:
        //		This is a store for RelateQueries and Autocomplete.
        //		It implements dojo/store/api/Store.

        priorityProperty: "priority",
        maxPriority: 2147483647,

        constructor: function (options) {
            this.idProperty = "id";
            this.listProperty = "hits";
            this.itemProperty = "item";
            declare.safeMixin(this, options);
        },

        query: function (query, options) {
            // summary:
            //      Query method adapted to the nature of related queries endpoint.
            // description:
            //      Utilises the epi/shell/store/JsonRest "id-property to endpoint path" rewrite functionality
            //      to add "/list" to the endpoint target url on query requests.
            // tags:
            //      public
            query = lang.clone(query || {});
            query[this.idProperty] = "list"; // HACK: RelatedQueries and Autocomplete endpoints requires "/list" in order to get collection
            return this.inherited(arguments, [query, options]);
        },

        put: function(object, options) {

            // "before" property appears when Drag & Drop in dGrid is used
            if (options && options.hasOwnProperty("before")) {
                var superClassPut = this.getInherited(arguments),
                    results = new Deferred(),
                    newObject = lang.clone(object),
                    newOptions = lang.clone(options),
                    self = this,
                    query = {},
                    afterItem,
                    afterPriority = self.maxPriority,
                    beforePriority = 0;
                if (options.before) {
                    beforePriority = options.before[this.priorityProperty];
                    query = {priorityFrom: beforePriority};
                }
                var queryResults = self.query(query,{
                        start: 0,
                        count: 1,
                        sort: [{attribute: this.priorityProperty, descending: false}]
                });
                queryResults.then(function(afterItems) {
                    // find an item that should be after the current item
                    if (afterItems && afterItems.length) {
                        afterItem = afterItems[0];
                        afterPriority = afterItem[self.priorityProperty];
                    }
                    // calculate a new priority value for the current item as an average between
                    // priorities of "before" and "after" items
                    var newPriority = beforePriority + Math.round((afterPriority - beforePriority) / 2);
                    if (newPriority === beforePriority || newPriority === afterPriority) {
                        // notify about refresh with delay, since update on the elastic is delayed
                        setTimeout(function() {self.emit("refresh");}, 2000);
                    }
                    newObject[self.priorityProperty] = newPriority;
                    superClassPut.apply(self, [newObject, newOptions]).then(function (putResults) {
                        results.resolve(putResults);
                        self.emit("dndComplete", putResults);
                    }, function (error) {
                        results.reject(error);
                        self.emit("dndError", error);
                    });
                });

                return results;

            }
            return this.inherited(arguments);
        }

    });

});