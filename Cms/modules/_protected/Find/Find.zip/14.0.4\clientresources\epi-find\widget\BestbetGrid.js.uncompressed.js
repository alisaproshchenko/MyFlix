﻿define("epi-find/widget/BestbetGrid", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/date",
    "dojo/dom-class",
    "dojo/dom-construct",
    "dojo/when",

    "dojox/html/entities",

    "dijit/MenuItem",

    "dgrid/Grid",
    "dgrid/extensions/DijitRegistry",

    "put-selector/put",

    "epi/shell/widget/ContextMenu",
    "epi/shell/dgrid/Formatter",
    "epi-cms/dgrid/formatters",

    "epi-saas-base/widgets/_GridMoreMixin",
    "epi-saas-base/widgets/_AutoLoadScrollMixin",
    "epi-saas-base/widgets/_WidgetsInListMixin",
    "epi-saas-base/widgets/_NotificationMixin",
    "epi-saas-base/widgets/_GridContextMenuMixin",

    "./BestbetGridRow",

    "dojo/i18n!./nls/Bestbets"
],
    function(
             declare,
             lang,
             date,
             domClass,
             domConstruct,
             when,

             entities,

             MenuItem,

             Grid,
             DijitRegistry,

             put,

             ContextMenu,
             Formatter,
             formatters,

             _GridMoreMixin,
             _AutoLoadScrollMixin,
             _WidgetsInListMixin,
             _NotificationMixin,
             _GridContextMenuMixin,

             BestbetGridRow,
             i18n
             ) {

        // module:
        //      epi-find/widget/BestbetGrid

        return declare([Grid, _GridMoreMixin, _AutoLoadScrollMixin, Formatter, _GridContextMenuMixin, DijitRegistry, _WidgetsInListMixin, _NotificationMixin], {
            // summary:
            //     A grid designed to display Best Bets
            constructor: function() {
                // Sets the loader (#loadNextPage, available in _GridMoreMixn) to be used by the _AutoLoadScrollMixin
                this.loader = lang.hitch(this, this.loadNextPage);
            },
            contextMenu: new ContextMenu(),
            i18n: i18n,
            showHeader: false,
            margin: 40,
            columns: {
                phrases: {
                    renderCell: function(object, value, node, options) {
                        var item = new BestbetGridRow({
                            title: entities.encode(object.best_bet_target_title || object.best_bet_target_document_title || ""),
                            description: entities.encode(object.best_bet_target_description || object.best_bet_target_document_description || ""),
                            url: object.best_bet_target_url,
                            phrases: entities.encode(object.phrases)
                        }, node);
                        this.grid.own(item);
                        domConstruct.place(item.domNode, node);
                    }
                },
                expiration: {
                    className: "epi-grid--20 epi-alignMiddle",
                    renderCell: function(object, value, node, options) {
                        var status = object.best_bet_target_document_status || 0;
                        var div = put(node, "div.epi-expired-container");
                        if (status !== 0 && status !== 4 ) { // not published
                            put(div, "span.dijitIcon.dijitInline.dijitReset.epi-statusIndicatorIcon.epi-statusIndicator"+status);
                            put(div, "div", i18n["status_"+status]);
                        }
                    }
                },
                context: {
                    label: " ",
                    className: "epi-grid-column--icon24x24",
                    formatter: function() {
                        return formatters.menu({title: i18n.contextMenuTitle});
                    }
                }
            },

            postCreate: function() {
                this.inherited(arguments);

                var self = this,
                    getCurrentItem = function(context) {
                        var row = self.getRow(context);
                        return encodeURIComponent(row.id);
                    },
                    editMenuItem = new MenuItem({
                        label: i18n.actions_edit,
                        onClick: function() {
                            self.onEdit(getCurrentItem(this));
                        }
                    }),
                    deleteMenuItem = new MenuItem({
                        label: i18n.actions_delete,
                        onClick: function() {
                            var id = getCurrentItem(this);
                            self.showConfirmation({
                                title: i18n.deleteBestbet,
                                message: i18n.areYouSure,
                                confirmActionText: i18n.buttons_confirmDelete,
                                cancelActionText: i18n.buttons_cancelDelete,
                                action: function() {
                                    when(self.store.remove(id),
                                        function() {
                                            self.showSuccess(i18n.deletedMessage);
                                        },
                                        function(error) {
                                            self.showError(error);
                                            self.refresh();
                                        }
                                    );
                                }
                            });
                        }
                    });

                this.own(editMenuItem, deleteMenuItem,
                    this.on("dgrid-error", function(error) {
                        self.showErrorInGrid(error);
                    })
                );
                this.contextMenu.addChild(editMenuItem);
                this.contextMenu.addChild(deleteMenuItem);
            },

            onEdit: function(id) {
                // summary:
                //      A callback for Edit action
            }

        });
    });
