require({cache:{
'url:epi-find/widget/templates/AutocompleteForm.html':"<form data-dojo-attach-point='containerNode' data-dojo-attach-event='onreset:_onReset,onsubmit:_onSubmit' class='epi-formsWidgetWrapper'>\n    <ol class='epi-formsWidgetWrapper'>\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\" data-dojo-attach-point=\"autocompletePhraseListItem\">\n            <input id=\"autocompletePhrase\" data-dojo-attach-point=\"phraseField\" data-dojo-type=\"epi-find/widget/PhraseValidationTextBox\" data-dojo-props=\"required:true, intermediateChanges: true, invalidMessage: '${i18nPhraseHelp}'\"/>\n        </li>\n\n        <li data-dojo-type=\"epi-saas-base/form/FormListItem\" class=\"epi-formsRow--align-right\">\n            <input data-dojo-attach-point=\"submitButton\" type=\"submit\" data-dojo-type=\"dijit/form/Button\" class=\"epi-primary\" />\n            <input data-dojo-attach-point=\"resetButton\" type=\"reset\" data-dojo-type=\"dijit/form/Button\" />\n        </li>\n    </ol>\n</form>\n"}});
define("epi-find/widget/AutocompleteForm", [
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/_base/event",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/when",

    "dojox/mvc/at",
    "dijit/form/Form",
    "dijit/_WidgetsInTemplateMixin",
    // widgets used in the template
    "dijit/form/Button",
    "dijit/form/ValidationTextBox",

    "epi-find/widget/PhraseValidationTextBox",
    "epi-saas-base/UnicodeLetterRegexp",
    "epi-saas-base/form/FormListItem",
    "epi-saas-base/widgets/_ActionButtonsMixin",
    "epi-saas-base/widgets/_NotificationMixin",

    "dojo/text!./templates/AutocompleteForm.html",
    "dojo/i18n!./nls/Autocomplete"

],
    function(declare,
             config,
             event,
             lang,
             topic,
             when,

             at,

             Form,
             _WidgetsInTemplateMixin,
             Button,
             ValidationTextBox,
             PhraseValidationTextBox,
             UnicodeLetterRegExp,
             FormListItem,
             _ActionButtonsMixin,
             _NotificationMixin,

             template,
             i18n
        ) {
        // module:
        //      epi-find/widget/AutocompleteForm
        return declare([Form, _WidgetsInTemplateMixin, _NotificationMixin, _ActionButtonsMixin], {


            baseClass: "",
            model: null,
            i18n: i18n,
            templateString: template,

            i18nPhraseHelp: i18n.help_phrase,

            postCreate: function() {
                this.inherited(arguments);
                this.autocompletePhraseListItem.set("label", i18n.fields_phrase);
                this.autocompletePhraseListItem.set("help", i18n.help_phrase);
                this.resetButton.set("label", i18n.buttons_cancel);
            },

            startup:function() {
                this.inherited(arguments);

                this.actionButtons = [this.submitButton, this.resetButton];
                this.enabledWhenNoChangesButtons = [this.resetButton];

                this.phraseField.set("value", at(this.model.ctrl, "query"));
                this.phraseField.set("regExp", "[^~`!@%^*()\\[\\]\\{\\}:;'|/<>?_-](?:"+UnicodeLetterRegExp+"|[0-9&'+#$_.\\-\\s])*");

                this.submitButton.set("label", i18n.buttons_add);
                this.reset();
                this.own(this.watchDataChanges(this.model.ctrl));

            },

            onSubmit: function (e) {
                var self = this;
                event.stop(e);
                if (!this.validate()) {
                    return ;
                }
                this.submitButton.focus();
                this.indicateInProgress(this.submitButton);
                when(this.model.save(),
                    function (result) {
                        self.reset();
                        self.showSuccess(i18n.savedMessage);
                        topic.publish(config.intents.view.autocomplete);
                        self.afterSubmit({item: result});
                        self.indicateSuccess();
                        self.phraseField.focus();
                    },
                    function (error) {
                        self.showError(error);
                        self.indicateError();
                    }
                );
            },

            onReset: function() {
                this.model.ctrl.reset();
                this.model.ctrl.empty();
                this.submitButton.set("label", i18n.buttons_add);
                return this.inherited(arguments);
            },

            edit: function(id) {
                if (this.editMode) {
                    this.reset();
                }

                when(this.model.ctrl.getStore(id),
                    lang.hitch(this, function() {
                        this.phraseField.focus();
                        this.submitButton.set("label", i18n.buttons_save);
                        this.set("hasChanges", false);
                    }),
                    lang.hitch(this, function(error) {
                        this.showError(error);
                    })
                );

            },

            submit: function() {
                // summary:
                //      pragmatically submit form if and only if the `onSubmit` returns true
                if (this.onSubmit() === false) {
                    return;
                }
                this.originalContainerNode.submit();
            },

            afterSubmit: function(/*Object*/ e) {
                // summary:
                //      Refresh callback
                // e: Object
                //      Callback arguments, e.items contains an array of submitted entities
            }

        });

    });
