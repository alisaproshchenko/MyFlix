require({cache:{
'url:epi-find/widget/templates/Bestbets.html':"<div>\n    <div class=\"epi-vertical-spacer--double\">\n        <p class=\"epi-view--description\">${i18n.description}</p>\n        <form data-dojo-attach-point=\"bestbetForm\"></form>\n        <p class=\"epi-help\">${i18n.help_table}</p>\n    </div>\n\n    <div class=\"epi-grid-title-search\" data-dojo-attach-point=\"bestBetsHeader\">\n        <h1>${i18n.header}</h1>\n        <div class=\"epi-search-box\">\n            <input type=\"text\" name=\"query\"\n                   class=\"epi-search-input\"\n                   data-dojo-type=\"dijit/form/TextBox\"\n                   data-dojo-props=\"trim: true, intermediateChanges: true\"\n                   data-dojo-attach-point=\"searchNode\" placeholder=\"${i18n.search}\" />\n        </div>\n    </div>\n    <div id=\"bestbetGrid\" data-dojo-attach-point=\"bestbetGrid\"></div>\n</div>"}});
﻿define("epi-find/widget/Bestbets", [
    "dojo/_base/config",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/Stateful",

    "dojo/store/Observable",

    "dojox/mvc/EditStoreRefController",

    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/_FocusMixin",
    "dijit/form/TextBox",

    "epi-saas-base/Sticker",
    "epi-saas-base/mvc/_CommitReturnMixin",
    "epi-saas-base/mvc/_EmptiableRefControllerMixin",
    "../ConfigModel",

    "./_SiblingFocusMixin",
    "./_ActionableMixin",
    "./_DisabledViewMixin",
    "./BestbetForm",
    "./BestbetGrid",


    "dojo/i18n!./nls/Bestbets",
    "dojo/text!./templates/Bestbets.html"
],
function(config,
         declare,
         lang,
         domClass,
         Stateful,

        Observable,

        EditStoreRefController,

        _WidgetBase,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,
        _FocusMixin,
        TextBox,

        Sticker,
        _CommitReturnMixin,
        _EmptiableRefControllerMixin,
        ConfigModel,

        _SiblingFocusMixin,
        _ActionableMixin,
        _DisabledViewMixin,
        BestbetForm,
        BestbetGrid,
        i18n,
        template) {

    // module:
    //      epi-find/widget/Synonyms

    return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _FocusMixin, _SiblingFocusMixin, _ActionableMixin, _DisabledViewMixin], {
        // summary:
        //     Manage view.

        templateString: template,

        i18n: i18n,

        store: null,

        ctrl: null,

        _bestbetForm: null,
        _bestbetGrid: null,

        _searchText: null,

        _searchUpdateTimeout: 400,
        _searchUpdateTimer: null,

        constructor: function() {
            this.inherited(arguments);

            this.store = new Observable(config.dependencies["epi-find.BestBetStore"]);
        },

        takeAction: function(actions, params) {
            if (params && params.phrases) {
                this._bestbetForm.reset();
                this.ctrl.set("phrases", decodeURIComponent(params.phrases));
            }
            this._bestbetGrid.refresh();
        },

        postCreate: function() {
            this.inherited(arguments);
            var self = this;

            var EmptiableCommitController = declare([EditStoreRefController, _CommitReturnMixin, _EmptiableRefControllerMixin]);
            this.ctrl = new EmptiableCommitController({
                store: this.store,
                originalModel: new Stateful({ best_bet_has_own_style: true, target_type: "PageBestBetSelector" }),
                emptyModel: new Stateful({ best_bet_has_own_style: true, target_type: "PageBestBetSelector" })
            });

            this._bestbetForm = new BestbetForm({
                ctrl: this.ctrl
            }, this.bestbetForm);
            this.own(this._bestbetForm);

            this._bestbetGrid = new BestbetGrid({
                noDataMessage: i18n.noData,
                loadingMessage: i18n.dataLoading,
                showLoadingMessage: true,
                store: this.store,
                "class": "epi-plain-grid epi-plain-grid--no-border epi-plain-grid--no-header",
                onEdit: function(id) {
                    self._bestbetForm.edit(id);
					self._bestbetGrid.refresh();
                }
            }, this.bestbetGrid);

            this.own(
                this._bestbetGrid,
                this.searchNode.watch("value", function(name, oldValue, newValue) {
                    self._searchText = newValue;
                    self._delayedReload();
                })
            );

            domClass.toggle(this.searchNode.domNode, "epi-invisible", ConfigModel.getValue("api.best_bets.search") !== true);
        },

        refresh: function() {
            this._bestbetGrid.refresh();
            this._bestbetForm.reset();
            this.ctrl.empty();
        },

        startup: function(){
            this.inherited(arguments);
            var scrollNode = this.scrollNode || this.domNode.parentNode;
            this._bestbetForm.startup();
            this._bestbetGrid.set("scrollNode", scrollNode);
            this._bestbetGrid.startup();
            this.own(
                new Sticker({
                    domNode: this.bestBetsHeader,
                    offset: {top: 0},
                    scrollNode: scrollNode,
                    limitNode: this.bestbetGrid
                })
            );
        },

        _delayedReload: function() {
            //  summary:
            //      Updates grids query with text from the search textbox with delay.
            if (this._searchUpdateTimer) {
                clearTimeout(this._searchUpdateTimer);
            }
            this._searchUpdateTimer = setTimeout(lang.hitch(this, function () {
                this._searchUpdateTimer = null;
                this._bestbetGrid.set("query", this._searchText ? {q: this._searchText + "*"} : {});
            }), this._searchUpdateTimeout);
        }
    });
});
