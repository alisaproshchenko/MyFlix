define("epi-find/store/IdToNameResolvingMixin", [
        "dojo/_base/declare",
        "dojo/_base/config",
        "dojo/json",
		"dojox/html/entities"
],
function (declare, config, JSON) {
    return declare([], {
        // summary:
        //      Store mixin that finds out page names from the page IDs. Should be mixed to a ResourceStore based store.
        nameField: "SearchTitle$$string",
        nameFieldInBase64: "TitleInBase64$$string",

        query: function (query, options) {
            var self = this;
            function b64DecodeUnicode(str) {
                // Going backwards: from bytestream, to percent-encoding, to original string.
                return decodeURIComponent(atob(str).split("").map(function(c) {
                    return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
                }).join(""));
            }
			
            return this.inherited(arguments).then(function(results) {
                if (results.length === 0) {
                    return results;
                }

                // Let's resolve some names
                var mquery = "";
                for(var i in results) {
                    var split = results[i].id.split("/");
                    var body = {
                        fields: [self.nameField, self.nameFieldInBase64],
                        query: {
                            ids: {
                                type: split[0],
                                values: [split[1]]
                            }
                        }
                    };

                    mquery += "{}\n";
                    mquery += JSON.stringify(body) + "\n";
                }

                var nameField = self.nameField;
                var nameFieldInBase64 = self.nameFieldInBase64;

                return self.xhrHandler.xhr("POST", {
                    url: config.find.serviceApiBaseUrl+"_msearch",
                    handleAs: "json",
                    postData: mquery,
                    xsrfProtection: true
                }).then(function (nameResult) {
                    nameResult.responses.forEach(function(response, n) {
                        var hits = response.hits.hits;
                        // should only have one hit / msearch
                        if (hits && hits.length == 1) {
                            if(hits[0].fields.hasOwnProperty(nameField))
                            {
                                results[n].name = dojox.html.entities.encode(hits[0].fields[nameField]);
                            }
                            else if (hits[0].fields.hasOwnProperty(nameFieldInBase64))
                            {
                                results[n].name = dojox.html.entities.encode(b64DecodeUnicode(hits[0].fields[nameFieldInBase64]));
                            }
                            var index = hits[0]._index.split("-");
                            index.length === 2 ? results[n].language = index[1] : null;
                        }
                    });

                    return results;
                });
            });
        }
    });

});