define("epi-find/themes/charting/Statistics", ["dojox/charting/Theme", "dojox/gfx/gradutils", "dojox/charting/themes/common"], function(Theme, gradutils, themes){

    // Based on dojox/charting/themes/Charged

    var g = Theme.generateGradient,
        defaultFill = {type: "linear", space: "shape", x1: 0, y1: 0, x2: 0, y2: 75};

    themes.Statistics = new Theme({
        chart: {
            fill: "#faf9f4"
        },
        plotarea: {
            fill: "transparent"
        },
        axis:{
            stroke: { // the axis itself
                color: "#333",
                width: 1
            },
            tick: { // used as a foundation for all ticks
                color:     "#333",
                position:  "center",
                font:      "normal normal normal 7pt Helvetica, Arial, sans-serif", // labels on axis
                fontColor: "#333"                                // color of labels
            }
        },
        series: {
            stroke:  {width: 2, color: "#95c532"},
            fill: "#c6da5c",
            outline: null,
            font: "normal normal normal 8pt Helvetica, Arial, sans-serif",
            fontColor: "#808078"
        },
        marker: {
            stroke:  {width: 3, color: "#333"},
            outline: null,
            font: "normal normal normal 8pt Helvetica, Arial, sans-serif",
            fontColor: "#333"
        },
        seriesThemes: [
            {fill: g(defaultFill, "#cbe25e", "#cbe25e")}    // Gradient!
        ],
        markerThemes: [
            {fill: "#c6d964", stroke: {color: "#95c532"}}
        ]
    });

    themes.Statistics.next = function(elementType, mixin, doPost){
        var isLine = elementType == "line";
        if(isLine || elementType == "area"){
            // custom processing for lines: substitute colors
            var s = this.seriesThemes[this._current % this.seriesThemes.length];
            s.fill.space = "plot";
            if(isLine){
                s.stroke  = { width: 2.5, color: s.fill.colors[1].color};
            }
            if(elementType == "area"){
                s.fill.y2 = 90;
            }
            var theme = Theme.prototype.next.apply(this, arguments);
            // cleanup
            delete s.stroke;
            s.fill.y2 = 75;
            s.fill.space = "shape";
            return theme;
        }
        return Theme.prototype.next.apply(this, arguments);
    };

    themes.Statistics.post = function(theme, elementType){
        theme = Theme.prototype.post.apply(this, arguments);
        if((elementType == "slice" || elementType == "circle") && theme.series.fill && theme.series.fill.type == "radial"){
            theme.series.fill = gradutils.reverse(theme.series.fill);
        }
        return theme;
    };

    return themes.Statistics;
});
