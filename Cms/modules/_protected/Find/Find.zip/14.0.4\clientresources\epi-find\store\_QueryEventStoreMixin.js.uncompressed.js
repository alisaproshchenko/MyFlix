﻿define("epi-find/store/_QueryEventStoreMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/Evented"
],
function (declare, lang, when, Evented) {
    return declare([Evented], {

        query: function (query, options) {
            var results = this.inherited(arguments);

            when(results, lang.hitch(this, function(valueResults) {
                this.emit("store-query-complete", valueResults);
            }));

            return results;
        }
    });
});