﻿define("epi-find/ResponsiveMode", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/window",

    "dijit/Destroyable",
    "dijit/Viewport",

    "./_ResponsiveMixin"

], function (declare, lang, window,
             Destroyable, Viewport,
             _ResponsiveMixin) {
    var ResponsiveMode = declare([Destroyable, _ResponsiveMixin], {

        constructor: function() {
            this.own(
                Viewport.on("resize", lang.hitch(this, this.resize))
            );
            this.startup();
        },

        getNewSize : function() {
            return  window.getBox();
        }

    });
    var responsiveMode = new ResponsiveMode();
    return responsiveMode;
});
