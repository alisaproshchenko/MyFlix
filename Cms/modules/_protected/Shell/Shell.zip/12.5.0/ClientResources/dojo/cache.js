//>>built
define("dojo/cache",["./_base/kernel","./text"],function(_1){return _1.cache;});